extends Control


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
# Called when the node enters the scene tree for the first time.
func _ready():
	pass
var checkChecked = false
onready var panel = $HelpButton/Panel

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	self.margin_right = OS.window_size.x
	self.margin_bottom = OS.window_size.y


#func _on_Run_pressed():
#	if checkChecked == true:
#		self.visible = true
#
#
#func _on_Stop_pressed():
#	self.visible = false
#
#
#func _on_CheckBox_pressed():
#	checkChecked = true


func _on_HelpButton_pressed():
	if panel.visible == true:
		panel.visible = false
	else:
		panel.visible = true
