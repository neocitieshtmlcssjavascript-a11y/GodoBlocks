extends Node2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"

# MAIN VARIABLES
onready var formatMenu = $Bar/FormatBtn/FormatMenu
# DESCRIPTION VARIABLES
onready var helpBtn = $CanvasLayer/HelpControl
onready var descCheckbox = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Description/CheckBox

onready var mgName = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Description/NameTextbox
onready var auName = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Description/AuthorTextbox
onready var descName = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Description/DescTextbox
onready var mgName2 = $CanvasLayer/HelpControl/HelpButton/Panel/MinigameNameLabel
onready var auName2 = $CanvasLayer/HelpControl/HelpButton/Panel/AuthorLabel
onready var descName2 = $CanvasLayer/HelpControl/HelpButton/Panel/DescLabel

var descCheckboxChecked = false

# TIMER VARIABLES
onready var timerControl = $CanvasLayer2/TimerControl
onready var timerCheckbox = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Timer/LineEdit

onready var timerSlider = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Timer/TimerHSlider
onready var timerText = $CanvasLayer2/TimerControl/TimerText
onready var timerValue = $CanvasLayer2/TimerControl/TimerValue
onready var timerTimer = $CanvasLayer2/TimerControl/TimerValue/Timer
onready var timerValueVisual = $Bar/FormatBtn/FormatMenu/Control/Panel/TabContainer/Timer/TimerValueVisual

var timerCheckboxChecked = false
var gameRunning = false
# SCORE VARIABLES



# Called when the node enters the scene tree for the first time.
func _ready():
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	# DESCRIPTION CODE
	mgName2.text = mgName.text
	auName2.text = auName.text
	descName2.text = descName.text
	
	var format_string2 = "%s"

	# Using the '%' operator, the placeholder is replaced with the desired value
	var actual_string2 = format_string2 % stepify (timerTimer.time_left, 0.1)
	
	if gameRunning == true:
		timerValue.text = actual_string2
		
	if descCheckbox.pressed == false:
		descCheckboxChecked = false
	
# DESCRIPTION CHECKBOX
func _on_CheckBox_pressed():
	descCheckboxChecked = true

# START BUTTON
func _on_Run_pressed():
	gameRunning = true
	if descCheckboxChecked == true:
		helpBtn.visible = true
	if timerCheckboxChecked == true:
		timerTimer.start(-1) #uh

# STOP BUTTON
func _on_Stop_pressed():
	helpBtn.visible = false
	gameRunning = false
	timerValue.text = timerValueVisual.text

# TIMER SLIDER

func _on_TimerHSlider_value_changed(_value):
	var format_string = "%s"

	# Using the '%' operator, the placeholder is replaced with the desired value
	var actual_string = format_string % timerSlider.value

	timerValueVisual.text = actual_string
	timerTimer.wait_time = timerSlider.value
	timerValue.text = actual_string
	print(timerTimer.wait_time)

func _on_TimerCheckBox_toggled(_button_pressed):
	if timerCheckboxChecked == false:
		timerCheckboxChecked = true
		timerText.visible = true
		timerValue.visible = true
		print(timerCheckboxChecked)
	else:
		timerCheckboxChecked = false
		timerText.visible = false
		timerValue.visible = false
		print(timerCheckboxChecked)


func _on_ConfirmBtn_pressed():
	formatMenu.visible = false
