extends Node2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
onready var descCheckmark = $Control/Panel/TabContainer/Description/CheckBox
var descCheckmarkChecked = false
# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	pass

func _on_Close_pressed():
	visible = false


func _on_CheckBox_toggled(_button_pressed):
	pass


func _on_TimerCheckBox_toggled(_button_pressed):
	pass # Replace with function body.
