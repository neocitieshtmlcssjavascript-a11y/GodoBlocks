#extends Control
#
#var dragPoint = null
#
#func _on_Titlebar_gui_input(ev):
#	if ev is InputEventMouseButton:
#		if ev.button_index == BUTTON_LEFT:
#			if ev.pressed:
#				# Grab it.
#				dragPoint = get_global_mouse_position() - get_position()
#			else:
#				# Release it.
#				dragPoint = null
#
#	if ev is InputEventMouseMotion and dragPoint != null:
#		set_position(get_global_mouse_position() - dragPoint)
