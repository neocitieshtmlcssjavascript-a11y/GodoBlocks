extends Button


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
onready var dropdown = $FormatDropdown
onready var descBtn = $FormatDropdown/LvlDescBtn
onready var timerBtn = $FormatDropdown/LvlTimerBtn
onready var scoreBtn = $FormatDropdown/LvlScoreBtn
onready var menu = $FormatMenu
onready var menuTabs = $FormatMenu/Control/Panel/TabContainer

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	pass

func _on_FormatBtn_pressed():
	if dropdown.visible == true:
		dropdown.visible = false
	else:
		dropdown.visible = true


func _on_LvlDescBtn_pressed():
	menu.visible = true
	menuTabs.current_tab = 0
	dropdown.visible = false

func _on_LvlTimerBtn_pressed():
	menu.visible = true
	menuTabs.current_tab = 1
	dropdown.visible = false

func _on_LvlScoreBtn_pressed():
	menu.visible = true
	menuTabs.current_tab = 2
	dropdown.visible = false

