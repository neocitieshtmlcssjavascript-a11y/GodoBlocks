extends TextureButton


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
onready var BtnControls = get_node("/root/StartStopPanel")
var arrowOn = false
# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass


func _on_ArrowTool_pressed():
	if arrowOn == false:
		arrowOn = true
		BtnControls.arrowToolOn = arrowOn
		print(BtnControls.arrowToolOn)
	elif arrowOn == true:
		arrowOn = false
		BtnControls.arrowToolOn = arrowOn
		print(BtnControls.arrowToolOn)
