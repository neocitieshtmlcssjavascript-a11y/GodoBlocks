extends RigidBody

export(bool) var anchored = false
# Declare member variables here. Examples:
# var a = 2
# var b = "text"
onready var physTog = get_node("/root/PhysicsToggle")
onready var BtnControls = get_node("/root/StartStopPanel")
onready var PartCSG = $CollisionShape/CSG
onready var PartCollisionShape = $CollisionShape
var canClickWithArrowTool = false
var selectionOutline = "none"
var selected = false

var selectMaterial = preload("res://content/materials/arrowSelect2.tres")

var previousTransform = self.transform
# Called when the node enters the scene tree for the first time.
func _ready():
#	0 is rigid. 1 is static
	self.mode = physTog.epicvar


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	if Input.is_action_just_pressed("left_click"):
		if canClickWithArrowTool == true:
			if selected == false: #if part is not selected
				#it will create a new selectionOutline around the part
				selectionOutline = PartCSG.duplicate()
				selectionOutline.translation = PartCollisionShape.translation
				selectionOutline.translation.y = PartCollisionShape.translation.y
				selectionOutline.scale.x = PartCollisionShape.scale.x + 0.01
				selectionOutline.scale.y = PartCollisionShape.scale.y + 0.01
				selectionOutline.scale.z = PartCollisionShape.scale.z + 0.01
				selectionOutline.material = selectMaterial
				add_child(selectionOutline)
				selected = true
		elif canClickWithArrowTool == false and selected == true:
			remove_child(selectionOutline)
			selected = false
			print("yes")
	if physTog.runIf == true:
		if anchored == false:
			self.mode = physTog.epicvar
		previousTransform = self.transform
		physTog.runIf = false
	if physTog.runIf2 == true:
		self.mode = physTog.epicvar
		self.transform = previousTransform
		physTog.runIf2 = false

func _on_Area_mouse_entered():
	if BtnControls.arrowToolOn == true:
		canClickWithArrowTool = true
		print("entered")

func _on_Area_mouse_exited():
	if BtnControls.arrowToolOn == true:
		canClickWithArrowTool = false
		print("exited")
