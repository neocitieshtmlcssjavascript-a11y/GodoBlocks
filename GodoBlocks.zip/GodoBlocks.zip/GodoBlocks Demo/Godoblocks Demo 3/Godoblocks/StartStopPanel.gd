extends Panel


onready var run = $Run
onready var stop = $Stop
onready var buttonSound = $buttonSound

var arrowToolOn = false

onready var physTog = get_node("/root/PhysicsToggle")
#onready var part = get_node("/root/Part")

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass


func _on_Run_pressed():
	stop.visible = true
	stop.disabled = false
	run.visible = false
	run.disabled = true
	buttonSound.play(0)
	print("on")
	physTog.epicvar = 0
	physTog.runIf = true
	physTog.runIf2 = false
	print(physTog.epicvar)
func _on_Stop_pressed():
	stop.visible = false
	stop.disabled = true
	run.visible = true
	run.disabled = false
	buttonSound.play(0)
	print("off")
	physTog.epicvar = 1
	physTog.runIf2 = true
	physTog.runIf = false
	print(physTog.epicvar)

func _on_FormatBtn_pressed():
	pass # Replace with function body.

#func _on_ArrowTool_toggled(button_pressed):
#	if arrowToolOn == true:
#		arrowToolOn = false
#		print("arrowToolOn ", arrowToolOn)
#	else:
#		arrowToolOn = true
#		print("arrowToolOn ", arrowToolOn)

func _on_ArrowTool_pressed():
	if arrowToolOn == false:
		arrowToolOn = true
		#print(arrowToolOn)
	elif arrowToolOn == true:
		arrowToolOn = false
		#print(arrowToolOn)
