extends Panel


onready var run = $Run
onready var stop = $Stop
onready var buttonSound = $buttonSound

onready var physTog = get_node("/root/PhysicsToggle")

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass


func _on_Run_pressed():
	stop.visible = true
	run.visible = false
	buttonSound.play(0)
	print("on")
	physTog.epicvar = 0
	physTog.runIf = true
func _on_Stop_pressed():
	stop.visible = false
	run.visible = true
	buttonSound.play(0)
	print("off")
	physTog.epicvar = 1
	physTog.runIf2 = true
