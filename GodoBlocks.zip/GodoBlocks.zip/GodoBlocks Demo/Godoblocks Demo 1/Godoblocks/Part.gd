extends RigidBody

export(bool) var anchored = false
# Declare member variables here. Examples:
# var a = 2
# var b = "text"
onready var physTog = get_node("/root/PhysicsToggle")
var previousTransform = self.transform
# Called when the node enters the scene tree for the first time.
func _ready():
#	0 is rigid. 1 is static
	self.mode = 1


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	if physTog.runIf == true:
		if anchored == false:
			self.mode = physTog.epicvar
		previousTransform = self.transform
		physTog.runIf = false
	if physTog.runIf2 == true:
		self.mode = physTog.epicvar
		self.transform = previousTransform
		physTog.runIf2 = false
